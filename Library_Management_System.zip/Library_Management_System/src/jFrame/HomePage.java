package jFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

public class HomePage extends javax.swing.JFrame {
    private Connection con;
    Color mouseEnterColor = new Color(0, 0, 0);
    Color mouseExitColor = new Color(51, 51, 51);

    public HomePage() {
        initComponents();
        connectToDatabase();
        showPieChart();
        setBookDetails();
        setStudentDetails();
        updateCounts();
    }

    private void connectToDatabase() {
        try {
            String url = "jdbc:mysql://localhost:3306/library_ms";
            String user = "root";
            String password = "";
            con = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private void updateCounts() {
        try {
            PreparedStatement pstBooks = con.prepareStatement("SELECT COUNT(*) FROM book_details");
            ResultSet rsBooks = pstBooks.executeQuery();
            if (rsBooks.next()) {
                jLabel9.setText(String.valueOf(rsBooks.getInt(1)));
            }

            PreparedStatement pstStudents = con.prepareStatement("SELECT COUNT(*) FROM student_details");
            ResultSet rsStudents = pstStudents.executeQuery();
            if (rsStudents.next()) {
                jLabel28.setText(String.valueOf(rsStudents.getInt(1)));
            }

            PreparedStatement pstIssued = con.prepareStatement("SELECT COUNT(*) FROM issue_book_details WHERE status = 'Issued'");
            ResultSet rsIssued = pstIssued.executeQuery();
            if (rsIssued.next()) {
                jLabel34.setText(String.valueOf(rsIssued.getInt(1)));
            }

            PreparedStatement pstDefaulters = con.prepareStatement("SELECT COUNT(*) FROM issue_book_details WHERE due_date < ? AND status = 'Issued'");
            pstDefaulters.setDate(1, new java.sql.Date(new Date().getTime()));
            ResultSet rsDefaulters = pstDefaulters.executeQuery();
            if (rsDefaulters.next()) {
                jLabel52.setText(String.valueOf(rsDefaulters.getInt(1)));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching counts: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void showPieChart() {
        DefaultPieDataset pieDataset = new DefaultPieDataset();
        try {
            PreparedStatement pst = con.prepareStatement("SELECT course, COUNT(*) as count FROM student_details GROUP BY course");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                pieDataset.setValue(rs.getString("course"), rs.getDouble("count"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching pie chart data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        JFreeChart pieChart = ChartFactory.createPieChart("Students by Course", pieDataset, false, true, false);
        PiePlot piePlot = (PiePlot) pieChart.getPlot();
        piePlot.setSectionPaint("BCS", new Color(255, 255, 102));
        piePlot.setSectionPaint("BEng", new Color(102, 255, 102));
        piePlot.setSectionPaint("Other", new Color(255, 102, 153));
        piePlot.setBackgroundPaint(Color.white);

        ChartPanel chartPanel = new ChartPanel(pieChart);
        panelPieChart.removeAll();
        panelPieChart.add(chartPanel, BorderLayout.CENTER);
        panelPieChart.validate();
    }

    private void setBookDetails() {
        try {
            PreparedStatement pst = con.prepareStatement("SELECT book_id, book_name, author, quantity FROM book_details");
            ResultSet rs = pst.executeQuery();
            DefaultTableModel model = (DefaultTableModel) rSTableMetro1.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("book_id"), rs.getString("book_name"), rs.getString("author"), rs.getInt("quantity")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching book details: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setStudentDetails() {
        try {
            PreparedStatement pst = con.prepareStatement("SELECT student_id, name, course, branch FROM student_details");
            ResultSet rs = pst.executeQuery();
            DefaultTableModel model = (DefaultTableModel) rSTableMetro3.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("student_id"), rs.getString("name"), rs.getString("course"), rs.getString("branch")});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching student details: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jPanel39 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jLabel52 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        rSTableMetro1 = new rojeru_san.complementos.RSTableMetro();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        rSTableMetro3 = new rojeru_san.complementos.RSTableMetro();
        panelPieChart = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(102, 102, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_menu_48px_1.png")));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 50, 50));

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 5, Short.MAX_VALUE));
        jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 50, Short.MAX_VALUE));
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 5, 50));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 36));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("X");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1480, 10, 30, 50));

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 1, 22));
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("LIBRARY_MANAGEMNT_SYSTEM");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 420, 50));

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 1, 22));
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/male_user_50px.png")));
        jLabel5.setText("Welcome To ADMIN...");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 10, 350, 50));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 70));

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(255, 51, 51));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Home_26px_2.png")));
        jLabel7.setText("Home Page");
        jPanel5.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 160, 40));

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 340, 60));

        jPanel6.setBackground(new java.awt.Color(51, 51, 51));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel12.setForeground(new java.awt.Color(153, 153, 153));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Library_26px_1.png")));
        jLabel12.setText("LMS Dashboard");
        jPanel6.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 180, 40));

        jPanel3.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 340, 60));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel6.setForeground(new java.awt.Color(153, 153, 153));
        jLabel6.setText("Features");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 150, 20));

        jPanel21.setBackground(new java.awt.Color(51, 51, 51));
        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel26.setForeground(new java.awt.Color(153, 153, 153));
        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Book_26px.png")));
        jLabel26.setText("Manage Books");
        jLabel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel26MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel26MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel26MouseExited(evt);
            }

            private void jLabel26MouseClicked(MouseEvent evt) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        });
        jPanel21.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 180, 40));

        jPanel3.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, 340, 60));

        jPanel13.setBackground(new java.awt.Color(51, 51, 51));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel18.setForeground(new java.awt.Color(153, 153, 153));
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Read_Online_26px.png")));
        jLabel18.setText("Manage Students");
        jLabel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel18MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel18MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel18MouseExited(evt);
            }
        });
        jPanel13.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 180, 40));

        jPanel3.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 340, 60));

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel11.setForeground(new java.awt.Color(153, 153, 153));
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Sell_26px.png")));
        jLabel11.setText("Issue Book");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel11MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel11MouseExited(evt);
            }
        });
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 180, 40));

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 460, 340, 60));

        jPanel31.setBackground(new java.awt.Color(51, 51, 51));
        jPanel31.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel36.setForeground(new java.awt.Color(153, 153, 153));
        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Return_Purchase_26px.png")));
        jLabel36.setText("Return Book");
        jLabel36.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel36MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel36MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel36MouseExited(evt);
            }
        });
        jPanel31.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 180, 40));

        jPanel3.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 520, 340, 60));

        jPanel39.setBackground(new java.awt.Color(51, 51, 51));
        jPanel39.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel44.setForeground(new java.awt.Color(153, 153, 153));
        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_View_Details_26px.png")));
        jLabel44.setText("View Record");
        jLabel44.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel44MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel44MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel44MouseExited(evt);
            }
        });
        jPanel39.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 180, 40));

        jPanel3.add(jPanel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 580, 340, 60));

        jPanel25.setBackground(new java.awt.Color(51, 51, 51));
        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel30.setForeground(new java.awt.Color(153, 153, 153));
        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Books_26px.png")));
        jLabel30.setText("View Issued Books");
        jLabel30.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel30MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel30MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel30MouseExited(evt);
            }
        });
        jPanel25.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 200, 40));

        jPanel3.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 640, 340, 60));

        jPanel27.setBackground(new java.awt.Color(51, 51, 51));
        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel32.setForeground(new java.awt.Color(153, 153, 153));
        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Conference_26px.png")));
        jLabel32.setText("Defaulter List");
        jLabel32.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel32MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel32MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel32MouseExited(evt);
            }
        });
        jPanel27.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 180, 40));

        jPanel3.add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 700, 340, 60));

        jPanel9.setBackground(new java.awt.Color(102, 102, 255));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18));
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Exit_26px_2.png")));
        jLabel14.setText("Logout");
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel14MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel14MouseExited(evt);
            }
        });
        jPanel9.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 180, 40));

        jPanel3.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 760, 340, 60));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -80, 340, 910));

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));
        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel23.setBorder(javax.swing.BorderFactory.createMatteBorder(15, 0, 0, 0, new java.awt.Color(255, 51, 51)));
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 0, 50));
        jLabel9.setForeground(new java.awt.Color(102, 102, 102));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Book_Shelf_50px.png")));
        jLabel9.setText("10");
        jPanel23.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, -1, -1));

        jPanel22.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 260, 140));

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 1, 18));
        jLabel10.setForeground(new java.awt.Color(102, 102, 102));
        jLabel10.setText("Student Details");
        jPanel22.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, -1, -1));

        jLabel27.setFont(new java.awt.Font("Segoe UI Black", 1, 20));
        jLabel27.setForeground(new java.awt.Color(102, 102, 102));
        jLabel27.setText("No Of Students");
        jPanel22.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 50, -1, -1));

        jPanel24.setBorder(javax.swing.BorderFactory.createMatteBorder(15, 0, 0, 0, new java.awt.Color(102, 102, 255)));
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel28.setFont(new java.awt.Font("Segoe UI Black", 0, 50));
        jLabel28.setForeground(new java.awt.Color(102, 102, 102));
        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_People_50px.png")));
        jLabel28.setText("6");
        jPanel24.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, -1, -1));

        jPanel22.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 80, 260, 140));

        jPanel29.setBorder(javax.swing.BorderFactory.createMatteBorder(15, 0, 0, 0, new java.awt.Color(255, 51, 51)));
        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setFont(new java.awt.Font("Segoe UI Black", 0, 50));
        jLabel34.setForeground(new java.awt.Color(102, 102, 102));
        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Sell_50px.png")));
        jLabel34.setText("1");
        jPanel29.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, -1, -1));

        jPanel22.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 80, 260, 140));

        jLabel29.setFont(new java.awt.Font("Segoe UI Black", 1, 20));
        jLabel29.setForeground(new java.awt.Color(102, 102, 102));
        jLabel29.setText("Issued Books");
        jPanel22.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 50, -1, -1));

        jLabel35.setFont(new java.awt.Font("Segoe UI Black", 1, 20));
        jLabel35.setForeground(new java.awt.Color(102, 102, 102));
        jLabel35.setText("Defaulter List");
        jPanel22.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 50, -1, -1));

        jPanel30.setBorder(javax.swing.BorderFactory.createMatteBorder(15, 0, 0, 0, new java.awt.Color(102, 102, 255)));
        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel52.setFont(new java.awt.Font("Segoe UI Black", 0, 50));
        jLabel52.setForeground(new java.awt.Color(102, 102, 102));
        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_List_of_Thumbnails_50px.png")));
        jLabel52.setText("0");
        jPanel30.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, -1, -1));

        jPanel22.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 80, 260, 140));

        rSTableMetro1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"1", "ABC", "BCS", "srs"},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Book Id", "Name", "Author", "Quantity"
            }
        ));
        rSTableMetro1.setColorBackgoundHead(new java.awt.Color(102, 102, 255));
        rSTableMetro1.setColorBordeFilas(new java.awt.Color(102, 102, 255));
        rSTableMetro1.setColorFilasBackgound2(new java.awt.Color(255, 255, 255));
        /*rSTableMetro1.setColorSel51, 51));*/
        rSTableMetro1.setFont(new java.awt.Font("Segoe UI Semibold", 1, 18));
        rSTableMetro1.setRowHeight(30);
        jScrollPane1.setViewportView(rSTableMetro1);

        jPanel22.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 520, 610, 180));

        jLabel53.setFont(new java.awt.Font("Segoe UI Black", 1, 20));
        jLabel53.setForeground(new java.awt.Color(102, 102, 102));
        jLabel53.setText("No Of Books");
        jPanel22.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        jLabel54.setFont(new java.awt.Font("Segoe UI Black", 1, 18));
        jLabel54.setForeground(new java.awt.Color(102, 102, 102));
        jLabel54.setText("Book Details");
        jPanel22.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 480, -1, 20));

        rSTableMetro3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"1", "ABC", "BCS", "srs"},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Student Id", "Name", "Course", "Branch"
            }
        ));
        rSTableMetro3.setColorBackgoundHead(new java.awt.Color(102, 102, 255));
        rSTableMetro3.setColorBordeFilas(new java.awt.Color(102, 102, 255));
        rSTableMetro3.setColorFilasBackgound2(new java.awt.Color(255, 255, 255));
        /*rSTableMetro3.setColorSel51, 51));*/
        rSTableMetro3.setFont(new java.awt.Font("Segoe UI Semibold", 1, 18));
        rSTableMetro3.setRowHeight(30);
        jScrollPane3.setViewportView(rSTableMetro3);

        jPanel22.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 610, 180));

        panelPieChart.setLayout(new java.awt.BorderLayout());
        jPanel22.add(panelPieChart, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 280, 440, 420));

        getContentPane().add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 70, 1190, 760));

        setSize(new java.awt.Dimension(1523, 828));
        setLocationRelativeTo(null);
    }

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {
        int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to exit?", "Confirm Exit", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    private void jLabel26MouseClicked(java.awt.event.MouseEvent evt, HomePage aThis) {
        try {
            ManageBooks books = new ManageBooks(this, aThis);
            books.setVisible(true);
            this.setVisible(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error opening Manage Books: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void jLabel26MouseEntered(java.awt.event.MouseEvent evt) {
        jPanel21.setBackground(mouseEnterColor);
    }

    private void jLabel26MouseExited(java.awt.event.MouseEvent evt) {
        jPanel21.setBackground(mouseExitColor);
    }

    private void jLabel18MouseClicked(java.awt.event.MouseEvent evt) {
        try {
            ManageStudents students = new ManageStudents(this);
            students.setVisible(true);
            this.setVisible(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error opening Manage Students: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void jLabel18MouseEntered(java.awt.event.MouseEvent evt) {
        jPanel13.setBackground(mouseEnterColor);
    }

    private void jLabel18MouseExited(java.awt.event.MouseEvent evt) {
        jPanel13.setBackground(mouseExitColor);
    }

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {
        try {
            IssueBook issue = new IssueBook(this);
            issue.setVisible(true);
            this.setVisible(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error opening Issue Book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void jLabel11MouseEntered(java.awt.event.MouseEvent evt) {
        jPanel4.setBackground(mouseEnterColor);
    }

    private void jLabel11MouseExited(java.awt.event.MouseEvent evt) {
        jPanel4.setBackground(mouseExitColor);
    }

    private void jLabel36MouseClicked(java.awt.event.MouseEvent evt) {
        try {
            ReturnBook returnBook = new ReturnBook(this);
            returnBook.setVisible(true);
            this.setVisible(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error opening Return Book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void jLabel36MouseEntered(java.awt.event.MouseEvent evt) {
        jPanel31.setBackground(mouseEnterColor);
    }

    private void jLabel36MouseExited(java.awt.event.MouseEvent evt) {
        jPanel31.setBackground(mouseExitColor);
    }

    private void jLabel44MouseClicked(java.awt.event.MouseEvent evt) {
        try {
            ViewRecord record = new ViewRecord(this);
            record.setVisible(true);
            this.setVisible(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error opening View Record: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void jLabel44MouseEntered(java.awt.event.MouseEvent evt) {
        jPanel39.setBackground(mouseEnterColor);
    }

    private void jLabel44MouseExited(java.awt.event.MouseEvent evt) {
        jPanel39.setBackground(mouseExitColor);
    }

    private void jLabel30MouseClicked(java.awt.event.MouseEvent evt) {
        try {
            ViewIssuedBooks issued = new ViewIssuedBooks(this);
            issued.setVisible(true);
            this.setVisible(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error opening View Issued Books: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void jLabel30MouseEntered(java.awt.event.MouseEvent evt) {
        jPanel25.setBackground(mouseEnterColor);
    }

    private void jLabel30MouseExited(java.awt.event.MouseEvent evt) {
        jPanel25.setBackground(mouseExitColor);
    }

    private void jLabel32MouseClicked(java.awt.event.MouseEvent evt) {
        try {
            DefaulterList defaulters = new DefaulterList(this);
            defaulters.setVisible(true);
            this.setVisible(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error opening Defaulter List: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void jLabel32MouseEntered(java.awt.event.MouseEvent evt) {
        jPanel27.setBackground(mouseEnterColor);
    }

    private void jLabel32MouseExited(java.awt.event.MouseEvent evt) {
        jPanel27.setBackground(mouseExitColor);
    }

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {
        int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            LoginPage login = new LoginPage();
            login.setVisible(true);
            this.dispose();
        }
    }

    private void jLabel14MouseEntered(java.awt.event.MouseEvent evt) {
        jPanel9.setBackground(mouseEnterColor);
    }

    private void jLabel14MouseExited(java.awt.event.MouseEvent evt) {
        jPanel9.setBackground(new Color(102, 102, 255));
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new HomePage().setVisible(true);
        });
    }

    // Variables declaration
    private javax.swing.JLabel jLabel1, jLabel2, jLabel4, jLabel5, jLabel6, jLabel7, jLabel9, jLabel10;
    private javax.swing.JLabel jLabel11, jLabel12, jLabel14, jLabel18, jLabel26, jLabel27, jLabel28, jLabel29;
    private javax.swing.JLabel jLabel30, jLabel32, jLabel34, jLabel35, jLabel36, jLabel44, jLabel52, jLabel53, jLabel54;
    private javax.swing.JPanel jPanel1, jPanel2, jPanel3, jPanel4, jPanel5, jPanel6, jPanel9, jPanel13;
    private javax.swing.JPanel jPanel21, jPanel22, jPanel23, jPanel24, jPanel25, jPanel27, jPanel29, jPanel30, jPanel31, jPanel39;
    private javax.swing.JScrollPane jScrollPane1, jScrollPane3;
    private javax.swing.JPanel panelPieChart;
    private rojeru_san.complementos.RSTableMetro rSTableMetro1, rSTableMetro3;

    // Placeholder classes (replace with actual implementations)
    private static class ManageBooks extends javax.swing.JFrame {
        public ManageBooks(HomePage parent, ManageBooks aThis) {
            ManageBooks books = new ManageBooks(aThis);
            books.setVisible(true);
            this.setVisible(false);
        }

        private ManageBooks(ManageBooks aThis) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private ManageBooks(HomePage aThis, HomePage aThis0) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    private static class ManageStudents extends javax.swing.JFrame {
        public ManageStudents(HomePage parent) {
            // Initialize
        }
    }

    private static class IssueBook extends javax.swing.JFrame {
        public IssueBook(HomePage parent) {
            // Initialize
        }
    }

    private static class ReturnBook extends javax.swing.JFrame {
        public ReturnBook(HomePage parent) {
            // Initialize
        }
    }

    private static class ViewRecord extends javax.swing.JFrame {
        public ViewRecord(HomePage parent) {
            // Initialize
        }
    }

    private static class ViewIssuedBooks extends javax.swing.JFrame {
        public ViewIssuedBooks(HomePage parent) {
            // Initialize
        }
    }

    private static class DefaulterList extends javax.swing.JFrame {
        public DefaulterList(HomePage parent) {
            // Initialize
        }
    }

    private static class LoginPage extends javax.swing.JFrame {
        public LoginPage() {
            // Initialize
        }
    }
}