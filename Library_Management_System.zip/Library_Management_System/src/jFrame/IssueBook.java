/*
 * Library Management System - Issue Book
 */
package jFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class IssueBook extends JFrame {

    private Connection con;
    private PreparedStatement pst;
    private JTextField txt_bookId, txt_studentId;
    private JFormattedTextField date_issueDate, date_dueDate;
    private JLabel lbl_bookId, lbl_bookName, lbl_author, lbl_quantity;
    private JLabel lbl_studentId, lbl_studentName, lbl_course, lbl_branch;
    private JPanel panel_main;

    public IssueBook() {
        initComponents();
        date_issueDate.setText(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
    }

    IssueBook(HomePage aThis) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void initComponents() {
        setTitle("Library Management System - Issue Book");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1537, 836);
        setLocationRelativeTo(null);

        panel_main = new JPanel();
        panel_main.setBackground(Color.WHITE);
        panel_main.setLayout(null);

        // Book Details Panel (Left)
        JPanel jPanel3 = new JPanel();
        jPanel3.setBackground(new Color(255, 51, 51));
        jPanel3.setBounds(0, 0, 420, 830);
        jPanel3.setLayout(null);

        JLabel jLabel12 = new JLabel("Book Details", new ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Literature_100px_1.png")), SwingConstants.LEFT);
        jLabel12.setFont(new Font("Segoe UI", Font.BOLD, 24));
        jLabel12.setForeground(Color.WHITE);
        jLabel12.setBounds(70, 80, 260, 110);
        jPanel3.add(jLabel12);

        JPanel jPanel6 = new JPanel();
        jPanel6.setBackground(Color.WHITE);
        jPanel6.setBounds(60, 190, 290, 5);
        jPanel3.add(jPanel6);

        JLabel jLabel15 = new JLabel("Book Id:");
        jLabel15.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        jLabel15.setForeground(Color.WHITE);
        jLabel15.setBounds(40, 300, 80, 30);
        jPanel3.add(jLabel15);

        lbl_bookId = new JLabel();
        lbl_bookId.setBounds(170, 300, 190, 30);
        jPanel3.add(lbl_bookId);

        JLabel jLabel13 = new JLabel("Book name:");
        jLabel13.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        jLabel13.setForeground(Color.WHITE);
        jLabel13.setBounds(40, 390, 110, 30);
        jPanel3.add(jLabel13);

        lbl_bookName = new JLabel();
        lbl_bookName.setBounds(170, 390, 190, 30);
        jPanel3.add(lbl_bookName);

        JLabel jLabel16 = new JLabel("Author:");
        jLabel16.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        jLabel16.setForeground(Color.WHITE);
        jLabel16.setBounds(40, 470, 80, 30);
        jPanel3.add(jLabel16);

        lbl_author = new JLabel();
        lbl_author.setBounds(180, 470, 190, 30);
        jPanel3.add(lbl_author);

        JLabel jLabel14 = new JLabel("Quantity:");
        jLabel14.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        jLabel14.setForeground(Color.WHITE);
        jLabel14.setBounds(40, 550, 80, 30);
        jPanel3.add(jLabel14);

        lbl_quantity = new JLabel();
        lbl_quantity.setBounds(170, 550, 190, 30);
        jPanel3.add(lbl_quantity);

        // Back Button
        JPanel jPanel5 = new JPanel();
        jPanel5.setBackground(new Color(102, 102, 255));
        jPanel5.setBounds(0, 0, 120, 60);
        jPanel5.setLayout(null);

        JLabel jLabel11 = new JLabel("Back", new ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Rewind_48px.png")), SwingConstants.LEFT);
        jLabel11.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        jLabel11.setForeground(Color.WHITE);
        jLabel11.setBounds(10, 10, 110, 40);
        jLabel11.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                dispose();
            }
        });
        jPanel5.add(jLabel11);
        jPanel3.add(jPanel5);

        // Student Details Panel (Right)
        JPanel jPanel1 = new JPanel();
        jPanel1.setBackground(new Color(102, 102, 255));
        jPanel1.setBounds(430, 0, 420, 830);
        jPanel1.setLayout(null);

        JLabel jLabel7 = new JLabel("Student Details", new ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Student_Registration_100px_2.png")), SwingConstants.LEFT);
        jLabel7.setFont(new Font("Segoe UI", Font.BOLD, 24));
        jLabel7.setForeground(Color.WHITE);
        jLabel7.setBounds(60, 80, 290, 110);
        jPanel1.add(jLabel7);

        JPanel jPanel2 = new JPanel();
        jPanel2.setBackground(Color.WHITE);
        jPanel2.setBounds(60, 190, 290, 5);
        jPanel1.add(jPanel2);

        JLabel jLabel5 = new JLabel("Student Id:");
        jLabel5.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        jLabel5.setForeground(Color.WHITE);
        jLabel5.setBounds(40, 300, 100, 30);
        jPanel1.add(jLabel5);

        lbl_studentId = new JLabel();
        lbl_studentId.setBounds(170, 300, 190, 30);
        jPanel1.add(lbl_studentId);

        JLabel jLabel3 = new JLabel("Student name:");
        jLabel3.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        jLabel3.setForeground(Color.WHITE);
        jLabel3.setBounds(40, 380, 130, 30);
        jPanel1.add(jLabel3);

        lbl_studentName = new JLabel();
        lbl_studentName.setBounds(180, 380, 190, 30);
        jPanel1.add(lbl_studentName);

        JLabel jLabel6 = new JLabel("Course:");
        jLabel6.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        jLabel6.setForeground(Color.WHITE);
        jLabel6.setBounds(40, 460, 80, 30);
        jPanel1.add(jLabel6);

        lbl_course = new JLabel();
        lbl_course.setBounds(170, 460, 190, 30);
        jPanel1.add(lbl_course);

        JLabel jLabel4 = new JLabel("Branch:");
        jLabel4.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        jLabel4.setForeground(Color.WHITE);
        jLabel4.setBounds(40, 550, 80, 30);
        jPanel1.add(jLabel4);

        lbl_branch = new JLabel();
        lbl_branch.setBounds(170, 550, 190, 30);
        jPanel1.add(lbl_branch);

        // Input Fields Panel (Center)
        JLabel jLabel2 = new JLabel("Issue Book", new ImageIcon(getClass().getResource("/AddNewBookIcons/icons8_Books_52px_1.png")), SwingConstants.LEFT);
        jLabel2.setFont(new Font("Segoe UI", Font.BOLD, 24));
        jLabel2.setForeground(new Color(255, 51, 51));
        jLabel2.setBounds(1050, 80, 260, 80);
        panel_main.add(jLabel2);

        JPanel jPanel4 = new JPanel();
        jPanel4.setBackground(new Color(255, 51, 51));
        jPanel4.setBounds(1040, 150, 290, 5);
        panel_main.add(jPanel4);

        JLabel jLabel9 = new JLabel("Book Id:");
        jLabel9.setFont(new Font("Segoe UI Black", Font.PLAIN, 17));
        jLabel9.setForeground(new Color(255, 51, 51));
        jLabel9.setBounds(950, 260, 100, 30);
        panel_main.add(jLabel9);

        txt_bookId = new JTextField("Enter Book Id");
        txt_bookId.setForeground(new Color(255, 51, 51));
        txt_bookId.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(255, 51, 51)));
        txt_bookId.setBounds(1060, 250, 360, 30);
        txt_bookId.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent evt) {
                String bookIdText = txt_bookId.getText().trim();
                if (!bookIdText.isEmpty() && !bookIdText.equals("Enter Book Id")) {
                    try {
                        int bookId = Integer.parseInt(bookIdText);
                        fetchBookDetails(bookId);
                    } catch (NumberFormatException e) {
                        clearBookLabels();
                        JOptionPane.showMessageDialog(IssueBook.this, "Invalid Book ID. Please enter a numeric value.", "Input Error", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    clearBookLabels();
                }
            }
        });
        txt_bookId.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (txt_bookId.getText().equals("Enter Book Id")) {
                    txt_bookId.setText("");
                }
            }
        });
        panel_main.add(txt_bookId);

        JLabel jLabel17 = new JLabel("Student Id:");
        jLabel17.setFont(new Font("Segoe UI Black", Font.PLAIN, 17));
        jLabel17.setForeground(new Color(255, 51, 51));
        jLabel17.setBounds(940, 340, 120, 30);
        panel_main.add(jLabel17);

        txt_studentId = new JTextField("Enter Student Id");
        txt_studentId.setForeground(new Color(255, 51, 51));
        txt_studentId.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(255, 51, 51)));
        txt_studentId.setBounds(1060, 330, 360, 30);
        txt_studentId.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent evt) {
                String studentIdText = txt_studentId.getText().trim();
                if (!studentIdText.isEmpty() && !studentIdText.equals("Enter Student Id")) {
                    try {
                        int studentId = Integer.parseInt(studentIdText);
                        fetchStudentDetails(studentId);
                    } catch (NumberFormatException e) {
                        clearStudentLabels();
                        JOptionPane.showMessageDialog(IssueBook.this, "Invalid Student ID. Please enter a numeric value.", "Input Error", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    clearStudentLabels();
                }
            }
        });
        txt_studentId.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (txt_studentId.getText().equals("Enter Student Id")) {
                    txt_studentId.setText("");
                }
            }
        });
        panel_main.add(txt_studentId);

        JLabel jLabel10 = new JLabel("Issue Date:");
        jLabel10.setFont(new Font("Segoe UI Black", Font.PLAIN, 17));
        jLabel10.setForeground(new Color(255, 51, 51));
        jLabel10.setBounds(940, 440, 120, 30);
        panel_main.add(jLabel10);

        date_issueDate = new JFormattedTextField();
        date_issueDate.setForeground(new Color(255, 51, 51));
        date_issueDate.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(255, 51, 51)));
        date_issueDate.setBounds(1060, 430, 360, 30);
        panel_main.add(date_issueDate);

        JLabel jLabel18 = new JLabel("Due Date:");
        jLabel18.setFont(new Font("Segoe UI Black", Font.PLAIN, 17));
        jLabel18.setForeground(new Color(255, 51, 51));
        jLabel18.setBounds(940, 550, 120, 30);
        panel_main.add(jLabel18);

        date_dueDate = new JFormattedTextField();
        date_dueDate.setForeground(new Color(255, 51, 51));
        date_dueDate.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(255, 51, 51)));
        date_dueDate.setBounds(1060, 540, 360, 30);
        panel_main.add(date_dueDate);

        JButton issueButton = new JButton("ISSUE BOOK");
        issueButton.setBackground(new Color(255, 51, 51));
        issueButton.setForeground(Color.WHITE);
        issueButton.setFont(new Font("Segoe UI", Font.BOLD, 18));
        issueButton.setBounds(960, 650, 440, 60);
        issueButton.addActionListener(e -> issueBook());
        panel_main.add(issueButton);

        // Close Button
        JPanel jPanel7 = new JPanel();
        jPanel7.setBackground(new Color(102, 102, 255));
        jPanel7.setBounds(1450, 0, 80, 60);
        jPanel7.setLayout(null);

        JLabel jLabel8 = new JLabel("X");
        jLabel8.setFont(new Font("Segoe UI", Font.BOLD, 29));
        jLabel8.setForeground(Color.WHITE);
        jLabel8.setBounds(30, 10, 30, 40);
        jLabel8.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                System.exit(0);
            }
        });
        jPanel7.add(jLabel8);
        panel_main.add(jPanel7);

        panel_main.add(jPanel1);
        panel_main.add(jPanel3);
        getContentPane().add(panel_main);

        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void fetchBookDetails(int bookId) {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
            String sql = "SELECT book_name, author, quantity FROM book_details WHERE book_id = ?";
            pst = con.prepareStatement(sql);
            pst.setInt(1, bookId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                lbl_bookId.setText(String.valueOf(bookId));
                lbl_bookName.setText(rs.getString("book_name"));
                lbl_author.setText(rs.getString("author"));
                lbl_quantity.setText(String.valueOf(rs.getInt("quantity")));
            } else {
                clearBookLabels();
                JOptionPane.showMessageDialog(this, "Book ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            closeResources();
        }
    }

    private void fetchStudentDetails(int studentId) {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
            String sql = "SELECT name, course, branch FROM student_details WHERE student_id = ?";
            pst = con.prepareStatement(sql);
            pst.setInt(1, studentId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                lbl_studentId.setText(String.valueOf(studentId));
                lbl_studentName.setText(rs.getString("name"));
                lbl_course.setText(rs.getString("course"));
                lbl_branch.setText(rs.getString("branch"));
            } else {
                clearStudentLabels();
                JOptionPane.showMessageDialog(this, "Student ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            closeResources();
        }
    }

    private void issueBook() {
        try {
            int bookId = Integer.parseInt(txt_bookId.getText().trim());
            int studentId = Integer.parseInt(txt_studentId.getText().trim());
            LocalDate issueDate = LocalDate.parse(date_issueDate.getText(), DateTimeFormatter.ISO_LOCAL_DATE);
            LocalDate dueDate = LocalDate.parse(date_dueDate.getText(), DateTimeFormatter.ISO_LOCAL_DATE);

            if (issueDate == null || dueDate == null) {
                JOptionPane.showMessageDialog(this, "Please enter both Issue Date and Due Date (YYYY-MM-DD).", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (dueDate.isBefore(issueDate)) {
                JOptionPane.showMessageDialog(this, "Due Date cannot be before Issue Date.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
            con.setAutoCommit(false);

            // Check book availability
            pst = con.prepareStatement("SELECT quantity FROM book_details WHERE book_id = ?");
            pst.setInt(1, bookId);
            ResultSet rs = pst.executeQuery();
            if (rs.next() && rs.getInt("quantity") > 0) {
                // Insert issue record
                pst = con.prepareStatement("INSERT INTO issue_details (book_id, student_id, issue_date, due_date) VALUES (?, ?, ?, ?)");
                pst.setInt(1, bookId);
                pst.setInt(2, studentId);
                pst.setDate(3, java.sql.Date.valueOf(issueDate));
                pst.setDate(4, java.sql.Date.valueOf(dueDate));
                pst.executeUpdate();

                // Decrease book quantity
                pst = con.prepareStatement("UPDATE book_details SET quantity = quantity - 1 WHERE book_id = ?");
                pst.setInt(1, bookId);
                pst.executeUpdate();

                con.commit();
                JOptionPane.showMessageDialog(this, "Book issued successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearAllFields();
            } else {
                JOptionPane.showMessageDialog(this, "Book not available or ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            rs.close();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid Book ID or Student ID. Please enter numeric values.", "Input Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use YYYY-MM-DD.", "Input Error", JOptionPane.WARNING_MESSAGE);
        } finally {
            closeResources();
        }
    }

    private void clearBookLabels() {
        lbl_bookId.setText("");
        lbl_bookName.setText("");
        lbl_author.setText("");
        lbl_quantity.setText("");
    }

    private void clearStudentLabels() {
        lbl_studentId.setText("");
        lbl_studentName.setText("");
        lbl_course.setText("");
        lbl_branch.setText("");
    }

    private void clearAllFields() {
        txt_bookId.setText("Enter Book Id");
        txt_studentId.setText("Enter Student Id");
        date_issueDate.setText(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
        date_dueDate.setText("");
        clearBookLabels();
        clearStudentLabels();
    }

    private void closeResources() {
        try {
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new IssueBook().setVisible(true));
    }
}